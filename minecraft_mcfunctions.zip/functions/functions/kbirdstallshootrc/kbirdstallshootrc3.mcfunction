
execute at @s run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword1,sort=nearest,limit=1,distance=..2]
execute at @s run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword2,sort=nearest,limit=1,distance=..2]
execute at @s run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword3,sort=nearest,limit=1,distance=..2]
execute at @s run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword4,sort=nearest,limit=1,distance=..2]
execute at @s run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword5,sort=nearest,limit=1,distance=..2]
execute at @s run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword6,sort=nearest,limit=1,distance=..2]

execute at @s[scores={kbirdcircleswordcount=6..}] run summon armor_stand ~ ~ ~ {NoGravity:1b,Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:3},Count:1b}],Tags:["kbirdshootsword","kbirdshootswordlevel3","kbirdshootsword6"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s[scores={kbirdcircleswordcount=5..}] run summon armor_stand ~ ~ ~ {NoGravity:1b,Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:3},Count:1b}],Tags:["kbirdshootsword","kbirdshootswordlevel3","kbirdshootsword5"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s[scores={kbirdcircleswordcount=4..}] run summon armor_stand ~ ~ ~ {NoGravity:1b,Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:3},Count:1b}],Tags:["kbirdshootsword","kbirdshootswordlevel3","kbirdshootsword4"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s[scores={kbirdcircleswordcount=3..}] run summon armor_stand ~ ~ ~ {NoGravity:1b,Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:3},Count:1b}],Tags:["kbirdshootsword","kbirdshootswordlevel3","kbirdshootsword3"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s[scores={kbirdcircleswordcount=2..}] run summon armor_stand ~ ~ ~ {NoGravity:1b,Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:3},Count:1b}],Tags:["kbirdshootsword","kbirdshootswordlevel3","kbirdshootsword2"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s[scores={kbirdcircleswordcount=1..}] run summon armor_stand ~ ~ ~ {NoGravity:1b,Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:3},Count:1b}],Tags:["kbirdshootsword","kbirdshootswordlevel3","kbirdshootsword1"],Rotation:[0f,0f],DisabledSlots:16191}

execute at @s[scores={kbirdcircleswordcount=6..}] run tp @e[tag=kbirdshootsword6,sort=nearest,limit=1] ~ ~ ~ ~180 ~
execute at @s[scores={kbirdcircleswordcount=5..}] run tp @e[tag=kbirdshootsword5,sort=nearest,limit=1] ~ ~ ~ ~-20 ~
execute at @s[scores={kbirdcircleswordcount=4..}] run tp @e[tag=kbirdshootsword4,sort=nearest,limit=1] ~ ~ ~ ~20 ~
execute at @s[scores={kbirdcircleswordcount=3..}] run tp @e[tag=kbirdshootsword3,sort=nearest,limit=1] ~ ~ ~ ~-10 ~
execute at @s[scores={kbirdcircleswordcount=2..}] run tp @e[tag=kbirdshootsword2,sort=nearest,limit=1] ~ ~ ~ ~10 ~
execute at @s[scores={kbirdcircleswordcount=1..}] run tp @e[tag=kbirdshootsword1,sort=nearest,limit=1] ~ ~ ~ ~ ~

scoreboard players set @s kbirdshootcd 0
scoreboard players set @s kbirdcircleswordcount 0