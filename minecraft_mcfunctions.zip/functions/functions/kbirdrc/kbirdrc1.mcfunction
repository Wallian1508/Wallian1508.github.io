scoreboard players reset @s kbirdcd

execute as @s at @s run function kbird:kbirdrcfire/kbirdrcfire1