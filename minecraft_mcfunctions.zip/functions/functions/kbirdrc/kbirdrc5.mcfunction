scoreboard players reset @s kbirdcd
scoreboard players reset @s kbirdRC

execute as @s at @s run function kbird:kbirdrcfire/kbirdrcfire5