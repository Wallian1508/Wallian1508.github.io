

scoreboard objectives add kbirdcd minecraft.custom:minecraft.play_time
scoreboard objectives add kbirdSTcd minecraft.custom:minecraft.play_time
scoreboard objectives add kbirdshootcd minecraft.custom:minecraft.play_time

scoreboard objectives add kbirdRC minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add kbirdSTRC minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add kbirdsneakornot minecraft.custom:minecraft.sneak_time

scoreboard objectives add kbirdcircleswordcount dummy
scoreboard objectives add kbird20 dummy
scoreboard objectives add kbird60 dummy
scoreboard objectives add kbird800 dummy

scoreboard players set @a kbirdcircleswordcount 0
scoreboard players set @a kbirdcd 60
scoreboard players set @a kbird20 20
scoreboard players set @a kbird60 60
scoreboard players set @a kbird800 800
scoreboard players set @a kbirdSTcd 800
