kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword4,sort=nearest,limit=1,distance=..2]

execute at @s run tp @e[type=armor_stand,tag=kbirdcirclesword1,limit=1,sort=nearest] ~ ~2 ~ ~ ~
execute at @s run tp @e[type=armor_stand,tag=kbirdcirclesword2,limit=1,sort=nearest] ~ ~2 ~ ~120 ~
execute at @s run tp @e[type=armor_stand,tag=kbirdcirclesword3,limit=1,sort=nearest] ~ ~2 ~ ~240 ~

