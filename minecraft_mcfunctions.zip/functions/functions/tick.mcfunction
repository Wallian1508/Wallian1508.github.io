
execute as @e[type=minecraft:armor_stand,tag=kbirdcirclesword1] at @s run tp @s ~ ~ ~ ~-10 ~
execute as @e[type=minecraft:armor_stand,tag=kbirdcirclesword2] at @s run tp @s ~ ~ ~ ~-10 ~
execute as @e[type=minecraft:armor_stand,tag=kbirdcirclesword3] at @s run tp @s ~ ~ ~ ~-10 ~
execute as @e[type=minecraft:armor_stand,tag=kbirdcirclesword4] at @s run tp @s ~ ~ ~ ~-10 ~
execute as @e[type=minecraft:armor_stand,tag=kbirdcirclesword5] at @s run tp @s ~ ~ ~ ~-10 ~
execute as @e[type=minecraft:armor_stand,tag=kbirdcirclesword6] at @s run tp @s ~ ~ ~ ~-10 ~

execute as @e[type=minecraft:armor_stand,tag=kbirdshootsword] at @s unless entity @a[distance=..30] run kill @s

execute as @e[tag=kbirdshootswordlevel1] at @s run damage @e[dx=0,dy=0,dz=0,type=!#job:shouldnt_hurt,limit=1] 10.0 minecraft:arrow by @p from @p
execute as @e[tag=kbirdshootswordlevel2] at @s run damage @e[dx=0,dy=0,dz=0,type=!#job:shouldnt_hurt,limit=1] 12.5 minecraft:arrow by @p from @p
execute as @e[tag=kbirdshootswordlevel3] at @s run damage @e[dx=0,dy=0,dz=0,type=!#job:shouldnt_hurt,limit=1] 15.0 minecraft:arrow by @p from @p
execute as @e[tag=kbirdshootswordlevel4] at @s run damage @e[dx=0,dy=0,dz=0,type=!#job:shouldnt_hurt,limit=1] 17.5 minecraft:arrow by @p from @p
execute as @e[tag=kbirdshootswordlevel5] at @s run damage @e[dx=0,dy=0,dz=0,type=!#job:shouldnt_hurt,limit=1] 20.0 minecraft:arrow by @p from @p

execute as @e[tag=kbirdshootsword] at @s run tp @s ^ ^ ^2

execute positioned as @a[scores={kbirdcircleswordcount=6..}] run tp @e[type=minecraft:armor_stand,tag=kbirdcirclesword6,sort=nearest,limit=1] ~ ~2 ~
execute positioned as @a[scores={kbirdcircleswordcount=5..}] run tp @e[type=minecraft:armor_stand,tag=kbirdcirclesword5,sort=nearest,limit=1] ~ ~2 ~
execute positioned as @a[scores={kbirdcircleswordcount=4..}] run tp @e[type=minecraft:armor_stand,tag=kbirdcirclesword4,sort=nearest,limit=1] ~ ~2 ~
execute positioned as @a[scores={kbirdcircleswordcount=3..}] run tp @e[type=minecraft:armor_stand,tag=kbirdcirclesword3,sort=nearest,limit=1] ~ ~2 ~
execute positioned as @a[scores={kbirdcircleswordcount=2..}] run tp @e[type=minecraft:armor_stand,tag=kbirdcirclesword2,sort=nearest,limit=1] ~ ~2 ~
execute positioned as @a[scores={kbirdcircleswordcount=1..}] run tp @e[type=minecraft:armor_stand,tag=kbirdcirclesword1,sort=nearest,limit=1] ~ ~2 ~

execute as @a if score @s kbirdSTcd matches 600 run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword1,sort=nearest,limit=1]
execute as @a if score @s kbirdSTcd matches 600 run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword2,sort=nearest,limit=1]
execute as @a if score @s kbirdSTcd matches 600 run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword3,sort=nearest,limit=1]
execute as @a if score @s kbirdSTcd matches 600 run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword4,sort=nearest,limit=1]
execute as @a if score @s kbirdSTcd matches 600 run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword5,sort=nearest,limit=1]
execute as @a if score @s kbirdSTcd matches 600 run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword6,sort=nearest,limit=1]

execute as @a if score @s kbirdSTcd matches 600 run scoreboard players set @s kbirdcircleswordcount 0

execute at @a[scores={kbirdcircleswordcount=1}] as @e[type=!#job:shouldnt_hurt,distance=..4] run damage @s 1 minecraft:player_attack by @p from @p
execute at @a[scores={kbirdcircleswordcount=2}] as @e[type=!#job:shouldnt_hurt,distance=..4] run damage @s 2 minecraft:player_attack by @p from @p
execute at @a[scores={kbirdcircleswordcount=3}] as @e[type=!#job:shouldnt_hurt,distance=..4] run damage @s 3 minecraft:player_attack by @p from @p
execute at @a[scores={kbirdcircleswordcount=4}] as @e[type=!#job:shouldnt_hurt,distance=..4] run damage @s 4 minecraft:player_attack by @p from @p
execute at @a[scores={kbirdcircleswordcount=5}] as @e[type=!#job:shouldnt_hurt,distance=..4] run damage @s 5 minecraft:player_attack by @p from @p
execute at @a[scores={kbirdcircleswordcount=6}] as @e[type=!#job:shouldnt_hurt,distance=..4] run damage @s 6 minecraft:player_attack by @p from @p

execute as @a[scores={kbirdRC=1..,kbirdcd=60..,kbirdsneakornot=0,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:16}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdrc/kbirdrc1
execute as @a[scores={kbirdRC=1..,kbirdcd=60..,kbirdsneakornot=0,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:17}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdrc/kbirdrc2
execute as @a[scores={kbirdRC=1..,kbirdcd=60..,kbirdsneakornot=0,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:18}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdrc/kbirdrc3
execute as @a[scores={kbirdRC=1..,kbirdcd=60..,kbirdsneakornot=0,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:19}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdrc/kbirdrc4
execute as @a[scores={kbirdRC=1..,kbirdcd=60..,kbirdsneakornot=0,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:20}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdrc/kbirdrc5

execute as @a[scores={kbirdshootcd=10..,kbirdRC=1..,kbirdsneakornot=0,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:16}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdshootrc/kbirdshootrc1
execute as @a[scores={kbirdshootcd=10..,kbirdRC=1..,kbirdsneakornot=0,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:17}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdshootrc/kbirdshootrc2
execute as @a[scores={kbirdshootcd=10..,kbirdRC=1..,kbirdsneakornot=0,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:18}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdshootrc/kbirdshootrc3
execute as @a[scores={kbirdshootcd=10..,kbirdRC=1..,kbirdsneakornot=0,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:19}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdshootrc/kbirdshootrc4
execute as @a[scores={kbirdshootcd=10..,kbirdRC=1..,kbirdsneakornot=0,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:20}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdshootrc/kbirdshootrc5

execute as @a[scores={kbirdSTRC=1..,kbirdSTcd=800..,kbirdsneakornot=1,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:16}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstrc
execute as @a[scores={kbirdSTRC=1..,kbirdSTcd=800..,kbirdsneakornot=1,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:17}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstrc
execute as @a[scores={kbirdSTRC=1..,kbirdSTcd=800..,kbirdsneakornot=1,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:18}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstrc
execute as @a[scores={kbirdSTRC=1..,kbirdSTcd=800..,kbirdsneakornot=1,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:19}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstrc
execute as @a[scores={kbirdSTRC=1..,kbirdSTcd=800..,kbirdsneakornot=1,kbirdcircleswordcount=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:20}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstrc

execute as @a[scores={kbirdSTRC=1..,kbirdsneakornot=1,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:16}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstallshootrc/kbirdstallshootrc1
execute as @a[scores={kbirdSTRC=1..,kbirdsneakornot=1,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:17}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstallshootrc/kbirdstallshootrc2
execute as @a[scores={kbirdSTRC=1..,kbirdsneakornot=1,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:18}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstallshootrc/kbirdstallshootrc3
execute as @a[scores={kbirdSTRC=1..,kbirdsneakornot=1,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:19}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstallshootrc/kbirdstallshootrc4
execute as @a[scores={kbirdSTRC=1..,kbirdsneakornot=1,kbirdcircleswordcount=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:20}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdstallshootrc/kbirdstallshootrc5

execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:16}}}] as @s run execute unless score @s job matches 2 as @s run title @s actionbar {"text":"閣下並非武士，無法使用該武器。","color":"red","bold":true}
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:17}}}] as @s run execute unless score @s job matches 2 as @s run title @s actionbar {"text":"閣下並非武士，無法使用該武器。","color":"red","bold":true}
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:18}}}] as @s run execute unless score @s job matches 2 as @s run title @s actionbar {"text":"閣下並非武士，無法使用該武器。","color":"red","bold":true}
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:19}}}] as @s run execute unless score @s job matches 2 as @s run title @s actionbar {"text":"閣下並非武士，無法使用該武器。","color":"red","bold":true}
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:20}}}] as @s run execute unless score @s job matches 2 as @s run title @s actionbar {"text":"閣下並非武士，無法使用該武器。","color":"red","bold":true}

execute as @a run scoreboard players operation @s kbird60 -= @s kbirdcd
execute as @a run scoreboard players operation @s kbird800 -= @s kbirdSTcd
execute as @a run scoreboard players operation @s kbird60 += @s kbird20
execute as @a run scoreboard players operation @s kbird800 += @s kbird20
execute as @a run scoreboard players operation @s kbird60 /= @s kbird20
execute as @a run scoreboard players operation @s kbird800 /= @s kbird20

execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:16}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdcddisplay
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:17}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdcddisplay
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:18}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdcddisplay
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:19}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdcddisplay
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomModelData:20}}}] as @s run execute if score @s job matches 2 as @s run function kbird:kbirdcddisplay

scoreboard players set @a kbird20 20
scoreboard players set @a kbird60 60
scoreboard players set @a kbird800 800
scoreboard players set @a kbirdRC 0
scoreboard players set @a kbirdSTRC 0
scoreboard players set @a kbirdsneakornot 0
