scoreboard players set @s kbirdshootcd 0

execute as @s[scores={kbirdcircleswordcount=6}] at @s run function kbird:kbirdcircleswordcount/kbirdcircleswordcount6
execute as @s[scores={kbirdcircleswordcount=5}] at @s run function kbird:kbirdcircleswordcount/kbirdcircleswordcount5
execute as @s[scores={kbirdcircleswordcount=4}] at @s run function kbird:kbirdcircleswordcount/kbirdcircleswordcount4
execute as @s[scores={kbirdcircleswordcount=3}] at @s run function kbird:kbirdcircleswordcount/kbirdcircleswordcount3
execute as @s[scores={kbirdcircleswordcount=2}] at @s run function kbird:kbirdcircleswordcount/kbirdcircleswordcount2
execute as @s[scores={kbirdcircleswordcount=1}] at @s run kill @e[type=minecraft:armor_stand,tag=kbirdcirclesword1,distance=..2,sort=nearest,limit=1]

scoreboard players remove @s kbirdcircleswordcount 1
execute at @s run summon armor_stand ~ ~ ~ {NoGravity:1b,Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:3},Count:1b}],Tags:["kbirdshootsword","kbirdshootswordlevel3"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s run tp @e[tag=kbirdshootsword,sort=nearest,limit=1] ~ ~ ~ ~ ~
scoreboard players set @s kbirdshootcd 0