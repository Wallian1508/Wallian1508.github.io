scoreboard players reset @s kbirdSTcd
scoreboard players reset @s kbirdSTRC
scoreboard players set @s kbirdcircleswordcount 6

execute at @s run summon armor_stand ~ ~ ~ {Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:2},Count:1b}],Tags:["kbirdcirclesword1"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s run summon armor_stand ~ ~ ~ {Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:2},Count:1b}],Tags:["kbirdcirclesword2"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s run summon armor_stand ~ ~ ~ {Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:2},Count:1b}],Tags:["kbirdcirclesword3"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s run summon armor_stand ~ ~ ~ {Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:2},Count:1b}],Tags:["kbirdcirclesword4"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s run summon armor_stand ~ ~ ~ {Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:2},Count:1b}],Tags:["kbirdcirclesword5"],Rotation:[0f,0f],DisabledSlots:16191}
execute at @s run summon armor_stand ~ ~ ~ {Invisible:1b,ArmorItems:[{},{},{},{id:"iron_ingot",tag:{CustomModelData:2},Count:1b}],Tags:["kbirdcirclesword6"],Rotation:[0f,0f],DisabledSlots:16191}

execute at @s run tp @e[type=armor_stand,tag=kbirdcirclesword1,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute at @s run tp @e[type=armor_stand,tag=kbirdcirclesword2,limit=1,sort=nearest] ~ ~ ~ ~60 ~
execute at @s run tp @e[type=armor_stand,tag=kbirdcirclesword3,limit=1,sort=nearest] ~ ~ ~ ~120 ~
execute at @s run tp @e[type=armor_stand,tag=kbirdcirclesword4,limit=1,sort=nearest] ~ ~ ~ ~180 ~
execute at @s run tp @e[type=armor_stand,tag=kbirdcirclesword5,limit=1,sort=nearest] ~ ~ ~ ~240 ~
execute at @s run tp @e[type=armor_stand,tag=kbirdcirclesword6,limit=1,sort=nearest] ~ ~ ~ ~300 ~
