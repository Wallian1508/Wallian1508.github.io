particle minecraft:sweep_attack ~ ~1.6 ~ 0 0 0 0 0 force 
scoreboard players add @s kbirdrccount 1
execute positioned ~-0.5 ~0.5 ~-0.5 run damage @e[dx=0,dy=0,dz=0,type=!#job:shouldnt_hurt,limit=1] 4 minecraft:player_attack by @s from @s
execute as @s if score @s kbirdrccount matches ..20 positioned ^ ^ ^1 run function kbird:kbirdrcfire/kbirdrcfire2

execute if score @s kbirdrccount matches 20.. as @s run scoreboard players reset @s kbirdrccount